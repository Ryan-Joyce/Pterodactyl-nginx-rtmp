# pterodactyl-Nextcloud



```
ghcr.io/finnie2006/nextcloud-ptero:latest
```

How to use:
1. Go to releases and download the json file
2. Import the egg like u normaly do
3. Create a new server
4. Navigate to the given port and ip and u are good to go just add ur files to the webroot folder
Note: if u want it using a domain then create a reverse proxy on the host (an example will be added later)

forked and edited from https://gitlab.com/tenten8401/pterodactyl-nginx
